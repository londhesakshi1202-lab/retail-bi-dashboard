
import streamlit as st
import pandas as pd
import plotly.express as px

st.set_page_config(page_title="Retail BI Executive Dashboard", layout="wide")

@st.cache_data
def load_data():
    return pd.read_csv("dashboard_ready_retail_data.csv", parse_dates=["Order_Date"])

df = load_data()
df["Year"] = df["Order_Date"].dt.year
df["Month"] = df["Order_Date"].dt.to_period("M").astype(str)

st.title("Retail Business Intelligence – Executive Dashboard")
st.caption("Interactive sales, profitability and regional performance dashboard")

# Sidebar slicers
st.sidebar.header("Dashboard Filters")
years = st.sidebar.multiselect("Year", sorted(df["Year"].unique()), default=sorted(df["Year"].unique()))
regions = st.sidebar.multiselect("Region", sorted(df["Region"].dropna().unique()), default=sorted(df["Region"].dropna().unique()))
categories = st.sidebar.multiselect("Category", sorted(df["Category"].dropna().unique()), default=sorted(df["Category"].dropna().unique()))

f = df[df["Year"].isin(years) & df["Region"].isin(regions) & df["Category"].isin(categories)].copy()

# KPI cards
revenue = f["Revenue"].sum()
orders = f["Order_ID"].nunique()
aov = f["Revenue"].mean()
profit = f["Profit"].sum()
margin = (profit / revenue * 100) if revenue else 0
cac_proxy = f["CAC_Proxy"].sum() / orders if orders else 0
repeat_rate = f["Repeat_Customer"].mean() * 100 if len(f) else 0

c1,c2,c3,c4,c5,c6 = st.columns(6)
c1.metric("Revenue", f"₹{revenue:,.0f}")
c2.metric("Orders", f"{orders:,}")
c3.metric("Average Order Value", f"₹{aov:,.0f}")
c4.metric("Profit", f"₹{profit:,.0f}")
c5.metric("Profit Margin", f"{margin:.2f}%")
c6.metric("CAC (proxy)", f"₹{cac_proxy:,.0f}")

st.info("CAC is shown as a proxy because the supplied retail dataset does not contain actual marketing/acquisition spend. Repeat-customer rate is used as a retention proxy because there is no churn-status field.")

# Monthly trend
monthly = f.groupby("Month", as_index=False).agg(Revenue=("Revenue","sum"), Profit=("Profit","sum"))
fig = px.line(monthly, x="Month", y=["Revenue","Profit"], markers=True,
              title="Monthly Revenue and Profit Trend")
st.plotly_chart(fig, use_container_width=True)

# Category + region
left, right = st.columns(2)
with left:
    cat = f.groupby("Category", as_index=False).agg(Revenue=("Revenue","sum"), Profit=("Profit","sum"))
    fig = px.bar(cat, x="Category", y=["Revenue","Profit"], barmode="group",
                 title="Category Performance")
    st.plotly_chart(fig, use_container_width=True)

with right:
    reg = f.groupby("Region", as_index=False).agg(Revenue=("Revenue","sum"), Profit=("Profit","sum"))
    fig = px.bar(reg, x="Region", y="Revenue", title="Regional Revenue")
    st.plotly_chart(fig, use_container_width=True)

# Geographic heatmap
geo = f.groupby("Region", as_index=False).agg(Revenue=("Revenue","sum"), Profit=("Profit","sum"))
region_coords = {
    "North": (28.6139, 77.2090),
    "South": (13.0827, 80.2707),
    "East": (22.5726, 88.3639),
    "West": (19.0760, 72.8777)
}
geo["lat"] = geo["Region"].map(lambda x: region_coords.get(x, (20.5937,78.9629))[0])
geo["lon"] = geo["Region"].map(lambda x: region_coords.get(x, (20.5937,78.9629))[1])
fig = px.scatter_geo(geo, lat="lat", lon="lon", size="Revenue", color="Profit",
                     hover_name="Region", projection="natural earth",
                     title="Regional Revenue Heatmap")
st.plotly_chart(fig, use_container_width=True)

# Drill-down table
st.subheader("Drill-down: Year → Category → Region")
drill = f.groupby(["Year","Category","Region"], as_index=False).agg(
    Revenue=("Revenue","sum"), Profit=("Profit","sum"), Orders=("Order_ID","nunique")
)
st.dataframe(drill.sort_values(["Year","Revenue"], ascending=[True,False]), use_container_width=True)

st.subheader("Dashboard Design Notes")
st.markdown("""
- **Visual hierarchy:** KPI cards → trend → category/region comparison → geographic view → drill-down table.
- **Slicers:** Year, Region and Category.
- **Drill-down:** Year, Category and Region table.
- **Temporal analysis:** Monthly revenue/profit trend.
- **Caution:** CAC and churn require dedicated marketing/customer lifecycle data for actual business values; this dashboard uses clearly labelled proxies.
""")
